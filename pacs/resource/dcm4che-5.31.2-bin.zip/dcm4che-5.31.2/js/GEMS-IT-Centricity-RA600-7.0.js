DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS-IT/Centricity RA600/7.0",
"4113xx10":"Number of images in study"
});
