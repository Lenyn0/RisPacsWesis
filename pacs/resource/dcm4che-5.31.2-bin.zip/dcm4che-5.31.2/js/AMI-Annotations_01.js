DCM4CHE.elementName.addDictionary({
"privateCreator":"AMI Annotations_01",
"3101xx10":"Annotation Sequence"
});
