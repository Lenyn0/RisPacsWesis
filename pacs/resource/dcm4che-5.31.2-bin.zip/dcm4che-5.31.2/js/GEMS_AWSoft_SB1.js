DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_AWSoft_SB1",
"0039xx50":"Reference to Study UID",
"0039xx51":"Reference to Series UID",
"0039xx52":"Reference to Original Instance Number",
"0039xx95":"Private Entity Launch Command"
});
