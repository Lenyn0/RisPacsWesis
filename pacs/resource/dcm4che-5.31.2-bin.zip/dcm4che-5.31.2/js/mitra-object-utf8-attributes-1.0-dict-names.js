DCM4CHE.elementName.addDictionary({
"privateCreator":"MITRA OBJECT UTF8 ATTRIBUTES 1.0",
"0033xx02":"?",
"0033xx04":"?",
"0033xx06":"?",
"0033xx08":"?",
"0033xx0A":"?",
"0033xx0C":"?",
"0033xx0E":"?",
"0033xx13":"?",
"0033xx14":"?",
"0033xx15":"?",
"0033xx16":"?",
"0033xx19":"?"
});
