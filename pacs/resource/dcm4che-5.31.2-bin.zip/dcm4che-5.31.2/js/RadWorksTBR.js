DCM4CHE.elementName.addDictionary({
"privateCreator":"RadWorksTBR",
"3111xx02":"Compression Type",
"3111xxFF":"Query Result"
});
