DCM4CHE.elementName.addDictionary({
"privateCreator":"FFP DATA",
"0009xx01":"CR Header Information"
});
