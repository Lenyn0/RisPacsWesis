DCM4CHE.elementName.addDictionary({
"privateCreator":"DLX_EXAMS_01",
"0015xx01":"Stenosis Calibration Ratio",
"0015xx02":"Stenosis Magnification",
"0015xx03":"Cardiac Calibration Ratio"
});
