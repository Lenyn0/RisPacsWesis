DCM4CHE.elementName.addDictionary({
"privateCreator":"ACUSON:1.2.840.113680.1.0:7ffe",
"7fdfxx00":"?"
});
