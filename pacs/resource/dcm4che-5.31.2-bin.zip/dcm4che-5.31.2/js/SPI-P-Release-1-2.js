DCM4CHE.elementName.addDictionary({
"privateCreator":"SPI-P Release 1;2",
"0029xx00":"Subtraction Mask ID",
"0029xx04":"Masking Function",
"0029xx0C":"Proprietary Masking Parameters",
"0029xx1E":"Subtraction Mask Enable Status",
"0029xx1F":"Subtraction Mask Select Status"
});
