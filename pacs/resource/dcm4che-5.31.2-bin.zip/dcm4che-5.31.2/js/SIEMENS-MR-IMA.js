DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MR IMA",
"0021xx01":"MR Image Sequence"
});
