DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SIENET",
"0019xx01":"?"
});
