DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_IT_US_REPORT",
"0045xx11":"Vivid excel file",
"0045xx12":"Vivid CHM file",
"0045xx13":"Vivid PDF file"
});
