DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MED PT WAVEFORM",
"0071xx46":"Starting Respiratory Amplitude",
"0071xx47":"Starting Respiratory Phase",
"0071xx48":"Ending Respiratory Amplitude",
"0071xx49":"Ending Respiratory Phase",
"0071xx50":"Respiratory Trigger Type"
});
