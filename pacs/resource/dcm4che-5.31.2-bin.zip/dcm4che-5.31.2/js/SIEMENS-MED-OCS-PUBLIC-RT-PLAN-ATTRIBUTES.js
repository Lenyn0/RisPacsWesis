DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MED OCS PUBLIC RT PLAN ATTRIBUTES",
"0039xx01":"External Attributes"
});
