DCM4CHE.elementName.addDictionary({
"privateCreator":"MITRA PRESENTATION 1.0",
"0029xx00":"Rotation",
"0029xx01":"Window Width",
"0029xx02":"Window Centre",
"0029xx03":"Invert",
"0029xx04":"Has Tabstop",
"0029xx05":"Smooth Rotation",
"0029xx10":"?",
"0029xx11":"?",
"0029xx12":"?",
"0029xx13":"?"
});
