DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_SENOCRYSTAL_V1",
"0055xx00":"Clinical View",
"0055xx01":"Exposure Dose",
"0055xx02":"Implant Displacement",
"0055xx03":"Paddle Type",
"0055xx04":"Processing Type",
"0055xx05":"Windowing Type",
"0055xx06":"Saturation",
"0055xx07":"Clip"
});
