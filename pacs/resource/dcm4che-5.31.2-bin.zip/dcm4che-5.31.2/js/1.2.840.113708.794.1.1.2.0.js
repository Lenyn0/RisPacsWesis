DCM4CHE.elementName.addDictionary({
"privateCreator":"1.2.840.113708.794.1.1.2.0",
"0087xx10":"Media Type",
"0087xx20":"Media Location",
"0087xx30":"Storage File ID",
"0087xx40":"Study or Image Size in MB",
"0087xx50":"Estimated Retrieve Time"
});
