DCM4CHE.elementName.addDictionary({
"privateCreator":"AMI Sequence AnnotElements_01",
"3105xx10":"Annotation Element Position",
"3105xx20":"Annotation Element Text"
});
