DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_FUNCTOOL_01",
"0051xx01":"Group Name",
"0051xx02":"Function Name",
"0051xx03":"Bias",
"0051xx04":"Scale",
"0051xx05":"Parameter Count",
"0051xx06":"Parameters",
"0051xx07":"Version",
"0051xx08":"Color Ramp Index",
"0051xx09":"Window Width",
"0051xx0A":"Window Level",
"0051xx0B":"B-Value",
"0051xx0C":"Wizard State Data Siz",
"0051xx0D":"Wizard State",
"0051xx0E":"?"
});
