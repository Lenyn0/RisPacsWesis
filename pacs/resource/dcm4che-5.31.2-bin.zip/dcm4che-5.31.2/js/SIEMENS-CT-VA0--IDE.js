DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS CT VA0  IDE",
"0009xx10":"?",
"0009xx30":"?",
"0009xx31":"?",
"0009xx32":"?",
"0009xx34":"?",
"0009xx40":"?",
"0009xx42":"?",
"0009xx50":"?",
"0009xx51":"?"
});
