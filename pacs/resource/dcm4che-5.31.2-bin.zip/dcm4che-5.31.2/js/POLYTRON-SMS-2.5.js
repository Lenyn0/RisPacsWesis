DCM4CHE.elementName.addDictionary({
"privateCreator":"POLYTRON-SMS 2.5",
"0009xx02":"?",
"0009xx04":"?",
"0009xx06":"?",
"0089xx10":"?"
});
