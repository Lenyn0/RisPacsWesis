DCM4CHE.elementName.addDictionary({
"privateCreator":"GEIIS PACS",
"0903xx10":"Reject Image Flag",
"0903xx11":"Significant Flag",
"0903xx12":"Confidential Flag",
"0903xx20":"?",
"0907xx21":"Prefetch Algorithm",
"0907xx22":"Limit Recent Studies",
"0907xx23":"Limit Oldest Studies",
"0907xx24":"Limit Recent Months",
"0907xx31":"Exclude Study UIDs"
});
