DCM4CHE.elementName.addDictionary({
"privateCreator":"Applicare/Centricity Radiology Web/Version 1.0",
"4109xx01":"Mammography Laterality",
"4109xx02":"Mammography View Name",
"4109xx03":"Mammography View Modifier"
});
