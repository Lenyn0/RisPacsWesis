DCM4CHE.elementName.addDictionary({
"privateCreator":"ACUSON:1.2.840.113680.1.0:0910",
"0009xx00":"?",
"0009xx01":"?",
"0009xx02":"Patient Registration Custom Field 1",
"0009xx03":"Patient Registration Custom Field 2",
"0009xx04":"Indications",
"0009xx0f":"?"
});
