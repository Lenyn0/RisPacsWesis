DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SYNGO DATA PADDING",
"7FDFxxFC":"Pixel Data Leading Padding"
});
