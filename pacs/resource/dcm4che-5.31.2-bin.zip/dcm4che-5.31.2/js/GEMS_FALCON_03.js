DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_FALCON_03",
"0045xx55":"A_Coefficients used in Multiresolution Algorithm",
"0045xx62":"User Window Center",
"0045xx63":"User Window Width",
"0045xx65":"Requested Detector Entrance Dose",
"0045xx67":"VOI LUT Assymmetry Parameter Beta",
"0045xx69":"Collimator Rotation",
"0045xx72":"Collimator Width",
"0045xx73":"Collimator Height"
});
