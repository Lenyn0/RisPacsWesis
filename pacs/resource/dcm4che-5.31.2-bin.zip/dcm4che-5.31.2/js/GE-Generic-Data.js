DCM4CHE.elementName.addDictionary({
"privateCreator":"GE Generic Data",
"6001xx50":"?",
"6001xx51":"?",
"6001xx52":"?"
});
