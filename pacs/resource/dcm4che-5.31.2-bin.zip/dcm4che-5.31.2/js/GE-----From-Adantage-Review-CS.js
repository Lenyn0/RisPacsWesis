DCM4CHE.elementName.addDictionary({
"privateCreator":"GE ??? From Adantage Review CS",
"0019xx30":"CR EDR Mode",
"0019xx40":"CR Latitude",
"0019xx50":"CR Group Number",
"0019xx70":"CR Image Serial Number",
"0019xx80":"CR Bar Code Number",
"0019xx90":"CR Film Output Exposures"
});
