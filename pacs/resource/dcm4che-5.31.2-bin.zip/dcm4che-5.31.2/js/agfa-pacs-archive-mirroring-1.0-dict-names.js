DCM4CHE.elementName.addDictionary({
"privateCreator":"AGFA PACS Archive Mirroring 1.0",
"0031xx00":"?",
"0031xx01":"?"
});
