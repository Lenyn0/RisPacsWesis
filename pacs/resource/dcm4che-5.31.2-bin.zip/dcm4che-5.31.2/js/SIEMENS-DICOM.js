DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS DICOM",
"0009xx10":"?",
"0009xx12":"?"
});
