DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_AWSOFT_CD1",
"0039xx65":"Reference to Study UID",
"0039xx70":"Reference to Series UID",
"0039xx75":"Reference to Original Instance Number",
"0039xx80":"DPO Number",
"0039xx85":"DPO Date",
"0039xx90":"DPO Time",
"0039xx95":"DPO Invocation String",
"0039xxAA":"DPO Type",
"0039xxFF":"DPO Data"
});
