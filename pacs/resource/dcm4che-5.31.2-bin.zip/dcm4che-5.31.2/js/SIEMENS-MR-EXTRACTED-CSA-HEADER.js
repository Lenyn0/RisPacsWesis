DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MR EXTRACTED CSA HEADER",
"0025xx01":"Extracted MR Header Information Sequence",
"0025xx02":"Extracted MR Header Creator Identification Code",
"0025xx03":"Extracted MR Header Tag"
});
