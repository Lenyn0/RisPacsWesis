DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips Imaging DD 067",
"4001xx00":"",
"4001xx01":"?",
"4001xx08":"?",
"4001xx09":"?"
});
