DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_Ultrasound_ImageGroup_001",
"6003xx10":"?",
"6003xx11":"?",
"6003xx12":"?",
"6003xx15":"?"
});
