DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS CT APPL MEASUREMENT",
"0029xx00":"Oncology Segmentation Measurement Values",
"0029xx01":"Oncology Measurement Recist Standard",
"0029xx10":"DualEnergy ROI Annotation Mode"
});
