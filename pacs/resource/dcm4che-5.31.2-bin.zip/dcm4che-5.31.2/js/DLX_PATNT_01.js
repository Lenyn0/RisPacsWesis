DCM4CHE.elementName.addDictionary({
"privateCreator":"DLX_PATNT_01",
"0011xx01":"Patient DOB"
});
