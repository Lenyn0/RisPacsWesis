DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips US Imaging DD 045",
"200DxxF1":"?",
"200DxxF3":"?",
"200DxxF4":"?",
"200DxxF5":"?",
"200DxxF6":"?",
"200DxxF8":"?",
"200DxxFA":"?",
"200DxxFB":"?"
});
