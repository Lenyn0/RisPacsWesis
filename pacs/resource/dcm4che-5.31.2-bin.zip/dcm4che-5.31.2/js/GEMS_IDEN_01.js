DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_IDEN_01",
"0009xx01":"Full Fidelity",
"0009xx02":"Suite Id",
"0009xx04":"Product Id",
"0009xx17":"?",
"0009xx1A":"?",
"0009xx20":"?",
"0009xx27":"Image Actual Date",
"0009xx2F":"?",
"0009xx30":"Service Id",
"0009xx31":"Mobile Location Number",
"0009xxE2":"?",
"0009xxE3":"Equipment UID",
"0009xxE6":"Genesis Version Now",
"0009xxE7":"Exam Record Checksum",
"0009xxE8":"Series Suite ID",
"0009xxE9":"Actual Series Data Time Stamp"
});
