DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS WH SR 1.0",
"0071xx01":"?",
"0071xx02":"?"
});
