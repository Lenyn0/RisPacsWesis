DCM4CHE.elementName.addDictionary({
"privateCreator":"MITRA OBJECT ATTRIBUTES 1.0",
"0033xx02":"?",
"0033xx04":"?",
"0033xx06":"?",
"0033xx08":"?",
"0033xx0A":"?"
});
