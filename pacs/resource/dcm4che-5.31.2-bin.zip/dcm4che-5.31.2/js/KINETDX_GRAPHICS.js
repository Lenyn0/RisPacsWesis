DCM4CHE.elementName.addDictionary({
"privateCreator":"KINETDX_GRAPHICS",
"0021xxA4":""
});
