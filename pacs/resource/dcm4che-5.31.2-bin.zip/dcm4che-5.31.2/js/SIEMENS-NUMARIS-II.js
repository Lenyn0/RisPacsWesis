DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS NUMARIS II",
"7FE3xx00":"Image Graphics Format Code",
"7FE3xx10":"Image Graphics",
"7FE3xx20":"Image Graphics Dummy"
});
