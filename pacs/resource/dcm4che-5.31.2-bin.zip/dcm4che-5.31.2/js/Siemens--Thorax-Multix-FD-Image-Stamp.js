DCM4CHE.elementName.addDictionary({
"privateCreator":"Siemens: Thorax/Multix FD Image Stamp",
"0023xx00":"?",
"0023xx01":"?",
"0023xx02":"?",
"0023xx03":"?",
"0023xx04":"?"
});
